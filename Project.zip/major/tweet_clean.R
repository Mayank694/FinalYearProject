### fetching tweets ###
download.file(url = "http://curl.haxx.se/ca/cacert.pem",
destfile = "cacert.pem")
setup_twitter_oauth('8iPM25VsTV1nGGh9KRgyftTq1', # api key
'OF7svBTg0g4pPgO4gkC1f3Fei9l5puox92NtW2MnUdPSM5wJmQ', # api secret
'797372905940078592-ylKsE17KVrJlV1L2O5tjYt3HgRq5woJ', # access token
'Z1EJGVDlTWhg8zuXLSxBbY7mO5Nc105RaRm8grLOsqLSp' # access token secret
)

 df_tweets <- twListToDF(searchTwitter('#JusticeForAsifa', n = 150, lang = 'en')) %>%
# converting some symbols
dmap_at('text', conv_fun)
 
# preprocessing and tokenization
it_tweets <- itoken(df_tweets$text,
preprocessor = prep_fun,
tokenizer = tok_fun,
ids = df_tweets$id,
progressbar = TRUE)
 
# creating vocabulary and document-term matrix
dtm_tweets <- create_dtm(it_tweets, vectorizer)
 
# transforming data with tf-idf
dtm_tweets_tfidf <- fit_transform(dtm_tweets, tfidf)
 
# loading classification model
glmnet_classifier <- readRDS('glmnet_classifier.RDS')
 
# predict probabilities of positiveness
preds_tweets <- predict(glmnet_classifier, dtm_tweets_tfidf, type = 'response')[ ,1]
 
# adding rates to initial dataset
df_tweets$sentiment <- preds_tweets
